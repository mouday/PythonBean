# -*- coding: utf-8 -*-

# @Date    : 2019-03-30
# @Author  : Peng Shiyu

from __future__ import unicode_literals, print_function
from .database import DataBase
from .document_similar import DocumentSimilar

